package com.chaoscraft.block;

import com.chaoscraft.ChaosCraft;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockBounceSlime extends Block {
    public BlockBounceSlime(String name) {
        super(Material.CLAY); setRegistryName(name); setTranslationKey(ChaosCraft.MODID + "." + name);
        setHardness(0.4F); setSoundType(SoundType.SLIME); setSlipperiness(0.92F); setCreativeTab(ChaosCraft.TAB);
    }
    @Override public void onFallenUpon(World world, BlockPos pos, Entity entity, float fallDistance) {
        if (!world.isRemote && !entity.isSneaking()) {
            entity.fallDistance = 0.0F;
            entity.motionY = Math.min(1.55D, Math.max(0.65D, fallDistance * 0.16D));
            entity.velocityChanged = true;
        } else {
            super.onFallenUpon(world, pos, entity, fallDistance);
        }
    }
}
