package com.chaoscraft.event;

import com.chaoscraft.config.ChaosConfig;
import com.chaoscraft.entity.EntityBuildBuddy;
import com.chaoscraft.entity.EntityChaosGremlin;
import com.chaoscraft.entity.EntityMegaChicken;
import com.chaoscraft.entity.EntityTNTChicken;
import com.chaoscraft.network.ChaosNetwork;
import com.chaoscraft.network.MessageScreenShake;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.potion.PotionEffect;
import net.minecraft.network.play.server.SPacketTitle;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import java.util.HashMap;
import java.util.UUID;

public class ChaosEngine {
    private static final Map<World, Long> NEXT_EVENT = new WeakHashMap<>();
    private static final Map<UUID, Long> GRAVITY_END = new HashMap<>();
    private static final Random RANDOM = new Random();

    public enum ChaosEvent {
        GRAVITY_FLIP("GRAVITY HAS LEFT THE BUILDING!", "Look out below. Or above."),
        TNT_CHICKENS("THE CHICKENS ARE ARMED!", "Eggs are now a workplace hazard."),
        SLIME_RAIN("SLIME WEATHER WARNING!", "The forecast says: boing."),
        TRAMPOLINE("THE WORLD IS A TRAMPOLINE!", "Try not to bounce into orbit."),
        GIANT_MODE("BIG TROUBLE!", "Something enormous just arrived."),
        TINY_TROUBLE("TINY TROUBLE!", "Everything is suddenly in a hurry."),
        CHICKEN_STAMPEDE("CHICKEN STAMPEDE!", "No one knows why they are running."),
        METEOR_PARTY("METEOR PARTY!", "The sky is throwing confetti."),
        DISCO_APOCALYPSE("DISCO APOCALYPSE!", "Dance like the server is lagging."),
        SUPER_SPEED("GOTTA GO FAST!", "Careful around corners."),
        RUBBER_WORLD("RUBBER WORLD!", "Every landing is a launchpad."),
        GREMLIN_AMBUSH("GREMLINS!", "They have chosen violence.");

        public final String title;
        public final String subtitle;
        ChaosEvent(String title, String subtitle) { this.title = title; this.subtitle = subtitle; }
    }

    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.world.isRemote || !(event.world instanceof WorldServer)) return;
        World world = event.world;
        if (world.playerEntities.isEmpty() || !ChaosConfig.ENABLE_RANDOM_EVENTS) return;
        long now = world.getTotalWorldTime();
        Long next = NEXT_EVENT.get(world);
        if (next == null) {
            NEXT_EVENT.put(world, now + randomInterval(world));
            return;
        }
        if (now >= next) {
            ChaosEvent[] events = ChaosEvent.values();
            ChaosEvent chosen = events[RANDOM.nextInt(events.length)];
            trigger(world, chosen);
            NEXT_EVENT.put(world, now + randomInterval(world));
        }
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.world.isRemote) return;
        Long until = GRAVITY_END.get(event.player.getUniqueID());
        if (until == null) return;
        if (event.player.world.getTotalWorldTime() >= until) {
            GRAVITY_END.remove(event.player.getUniqueID());
            return;
        }
        // Five seconds of low-gravity upward drift, not a teleport or instant kill.
        event.player.motionY = Math.max(event.player.motionY, 0.10D);
        event.player.velocityChanged = true;
        if (event.player.ticksExisted % 8 == 0) addParticles((WorldServer) event.player.world, event.player, EnumParticleTypes.PORTAL, 2);
    }

    private int randomInterval(World world) {
        int min = Math.max(1200, ChaosConfig.EVENT_MIN_TICKS);
        int max = Math.max(min, ChaosConfig.EVENT_MAX_TICKS);
        int interval = min + world.rand.nextInt(Math.max(1, max - min + 1));
        return Math.max(1200, interval / Math.max(1, ChaosConfig.CHAOS_LEVEL) * 3);
    }

    public static void trigger(World world, ChaosEvent chaosEvent) {
        if (world == null || world.isRemote || !(world instanceof WorldServer)) return;
        WorldServer serverWorld = (WorldServer) world;
        announce(serverWorld, chaosEvent);
        for (EntityPlayer player : serverWorld.playerEntities) {
            if (player.isDead) continue;
            if (ChaosConfig.ENABLE_EVENT_SOUNDS) {
                serverWorld.playSound(null, player.getPosition(), SoundEvents.ENTITY_FIREWORK_LAUNCH,
                        SoundCategory.MASTER, 0.8F, 0.65F + RANDOM.nextFloat() * 0.7F);
            }
            switch (chaosEvent) {
                case GRAVITY_FLIP:
                    GRAVITY_END.put(player.getUniqueID(), serverWorld.getTotalWorldTime() + 100L);
                    player.motionY = 0.75D;
                    player.velocityChanged = true;
                    addParticles(serverWorld, player, EnumParticleTypes.PORTAL, 18);
                    shake(player, 30);
                    break;
                case TNT_CHICKENS:
                    spawnTntChickens(serverWorld, player, 3 + ChaosConfig.CHAOS_LEVEL);
                    break;
                case SLIME_RAIN:
                    spawnSlimeRain(serverWorld, player, 5 + ChaosConfig.CHAOS_LEVEL * 2);
                    break;
                case TRAMPOLINE:
                case RUBBER_WORLD:
                    player.addPotionEffect(new PotionEffect(MobEffects.JUMP_BOOST, 360, 3 + ChaosConfig.CHAOS_LEVEL / 2));
                    player.addPotionEffect(new PotionEffect(MobEffects.SPEED, 360, 1));
                    shake(player, 18);
                    addParticles(serverWorld, player, EnumParticleTypes.SLIME, 16);
                    break;
                case GIANT_MODE:
                    spawnMegaChicken(serverWorld, player);
                    player.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 400, 0));
                    break;
                case TINY_TROUBLE:
                    player.addPotionEffect(new PotionEffect(MobEffects.SPEED, 500, 3));
                    player.addPotionEffect(new PotionEffect(MobEffects.JUMP_BOOST, 500, 2));
                    addParticles(serverWorld, player, EnumParticleTypes.VILLAGER_HAPPY, 24);
                    break;
                case CHICKEN_STAMPEDE:
                    spawnChickens(serverWorld, player, 8 + ChaosConfig.CHAOS_LEVEL * 3);
                    break;
                case METEOR_PARTY:
                    meteorParticles(serverWorld, player, 42);
                    shake(player, 22);
                    break;
                case DISCO_APOCALYPSE:
                    player.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 600, 0));
                    meteorParticles(serverWorld, player, 70);
                    break;
                case SUPER_SPEED:
                    player.addPotionEffect(new PotionEffect(MobEffects.SPEED, 500, 4));
                    player.addPotionEffect(new PotionEffect(MobEffects.HASTE, 500, 2));
                    break;
                case GREMLIN_AMBUSH:
                    spawnGremlins(serverWorld, player, Math.min(ChaosConfig.MAX_CHAOS_MOBS, 2 + ChaosConfig.CHAOS_LEVEL));
                    break;
                default: break;
            }
        }
    }

    private static void announce(WorldServer world, ChaosEvent event) {
        for (EntityPlayer player : world.playerEntities) {
            player.sendMessage(new TextComponentString("\u00a76[CHAOS] \u00a7e" + event.title + " \u00a77" + event.subtitle));
            if (player instanceof net.minecraft.entity.player.EntityPlayerMP) {
                net.minecraft.entity.player.EntityPlayerMP mp = (net.minecraft.entity.player.EntityPlayerMP) player;
                mp.connection.sendPacket(new SPacketTitle(SPacketTitle.Type.TITLE, new TextComponentString("\u00a7c" + event.title), 5, 35, 10));
                mp.connection.sendPacket(new SPacketTitle(SPacketTitle.Type.SUBTITLE, new TextComponentString("\u00a7f" + event.subtitle), 5, 35, 10));
            }
        }
    }

    private static void shake(EntityPlayer player, int ticks) {
        if (ChaosConfig.ENABLE_SCREEN_SHAKE && player instanceof net.minecraft.entity.player.EntityPlayerMP)
            ChaosNetwork.CHANNEL.sendTo(new MessageScreenShake(ticks), (net.minecraft.entity.player.EntityPlayerMP) player);
    }

    private static void addParticles(WorldServer world, Entity entity, EnumParticleTypes type, int count) {
        if (!ChaosConfig.ENABLE_PARTICLES) return;
        for (int i = 0; i < count; i++) {
            world.spawnParticle(type, entity.posX + (RANDOM.nextDouble() - 0.5D) * 3.0D,
                    entity.posY + RANDOM.nextDouble() * 2.0D,
                    entity.posZ + (RANDOM.nextDouble() - 0.5D) * 3.0D,
                    1, 0.2D, 0.2D, 0.2D, 0.02D);
        }
    }

    private static void meteorParticles(WorldServer world, EntityPlayer player, int count) {
        if (!ChaosConfig.ENABLE_PARTICLES) return;
        for (int i = 0; i < count; i++) {
            double x = player.posX + RANDOM.nextDouble() * 24.0D - 12.0D;
            double z = player.posZ + RANDOM.nextDouble() * 24.0D - 12.0D;
            double y = player.posY + 8.0D + RANDOM.nextDouble() * 16.0D;
            world.spawnParticle(EnumParticleTypes.FIREWORKS_SPARK, x, y, z, 1,
                    (RANDOM.nextDouble() - 0.5D) * 0.3D, -0.3D, (RANDOM.nextDouble() - 0.5D) * 0.3D, 0.08D);
        }
    }

    private static void spawnTntChickens(WorldServer world, EntityPlayer player, int count) {
        for (int i = 0; i < count && nearbyChaosCount(world, player) < ChaosConfig.MAX_CHAOS_MOBS; i++) {
            EntityTNTChicken chicken = new EntityTNTChicken(world);
            placeNear(chicken, player, world); world.spawnEntity(chicken);
        }
    }
    private static void spawnChickens(WorldServer world, EntityPlayer player, int count) {
        int nearby = world.getEntitiesWithinAABB(net.minecraft.entity.passive.EntityChicken.class,
                player.getEntityBoundingBox().grow(32.0D)).size();
        int allowed = Math.min(Math.min(count, 16), Math.max(0, 20 - nearby));
        for (int i = 0; i < allowed; i++) {
            net.minecraft.entity.passive.EntityChicken chicken = new net.minecraft.entity.passive.EntityChicken(world);
            placeNear(chicken, player, world); world.spawnEntity(chicken);
        }
    }
    private static void spawnSlimeRain(WorldServer world, EntityPlayer player, int count) {
        int nearby = world.getEntitiesWithinAABB(EntitySlime.class, player.getEntityBoundingBox().grow(32.0D)).size();
        int allowed = Math.min(Math.min(count, 12), Math.max(0, ChaosConfig.MAX_CHAOS_MOBS - nearby));
        for (int i = 0; i < allowed; i++) {
            EntitySlime slime = new EntitySlime(world); slime.setSlimeSize(1, true);
            slime.setPosition(player.posX + RANDOM.nextDouble() * 16.0D - 8.0D,
                    player.posY + 7.0D + RANDOM.nextDouble() * 6.0D,
                    player.posZ + RANDOM.nextDouble() * 16.0D - 8.0D);
            world.spawnEntity(slime);
        }
    }
    private static void spawnMegaChicken(WorldServer world, EntityPlayer player) {
        EntityMegaChicken chicken = new EntityMegaChicken(world);
        placeNear(chicken, player, world); world.spawnEntity(chicken);
    }
    private static void spawnGremlins(WorldServer world, EntityPlayer player, int count) {
        for (int i = 0; i < count && nearbyChaosCount(world, player) < ChaosConfig.MAX_CHAOS_MOBS; i++) {
            EntityChaosGremlin gremlin = new EntityChaosGremlin(world);
            placeNear(gremlin, player, world); world.spawnEntity(gremlin);
        }
    }
    private static void placeNear(Entity entity, EntityPlayer player, World world) {
        double x = player.posX + RANDOM.nextDouble() * 12.0D - 6.0D;
        double z = player.posZ + RANDOM.nextDouble() * 12.0D - 6.0D;
        entity.setPosition(x, world.getHeight((int) x, (int) z), z);
    }
    private static int nearbyChaosCount(World world, EntityPlayer player) {
        return world.getEntitiesWithinAABB(EntityTNTChicken.class, player.getEntityBoundingBox().grow(48.0D)).size()
                + world.getEntitiesWithinAABB(EntityChaosGremlin.class, player.getEntityBoundingBox().grow(48.0D)).size();
    }
}
