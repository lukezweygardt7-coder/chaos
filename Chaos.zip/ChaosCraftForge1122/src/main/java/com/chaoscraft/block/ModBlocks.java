package com.chaoscraft.block;

import com.chaoscraft.ChaosCraft;
import com.chaoscraft.item.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = ChaosCraft.MODID)
public final class ModBlocks {
    private ModBlocks() { }
    public static final Block CHAOS_ORE = new BlockChaosOre("chaos_ore");
    public static final Block BOUNCE_SLIME = new BlockBounceSlime("bounce_slime");
    public static final ItemBlock CHAOS_ORE_ITEM = new ItemBlock(CHAOS_ORE);
    public static final ItemBlock BOUNCE_SLIME_ITEM = new ItemBlock(BOUNCE_SLIME);

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll(CHAOS_ORE, BOUNCE_SLIME);
    }

    @SubscribeEvent
    public static void registerBlockItems(RegistryEvent.Register<Item> event) {
        CHAOS_ORE_ITEM.setRegistryName(CHAOS_ORE.getRegistryName());
        CHAOS_ORE_ITEM.setTranslationKey(ChaosCraft.MODID + ".chaos_ore");
        CHAOS_ORE_ITEM.setCreativeTab(ChaosCraft.TAB);
        BOUNCE_SLIME_ITEM.setRegistryName(BOUNCE_SLIME.getRegistryName());
        BOUNCE_SLIME_ITEM.setTranslationKey(ChaosCraft.MODID + ".bounce_slime");
        BOUNCE_SLIME_ITEM.setCreativeTab(ChaosCraft.TAB);
        event.getRegistry().registerAll(CHAOS_ORE_ITEM, BOUNCE_SLIME_ITEM);
    }
}
