package com.chaoscraft.block;

import com.chaoscraft.ChaosCraft;
import com.chaoscraft.item.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import java.util.Random;

public class BlockChaosOre extends Block {
    public BlockChaosOre(String name) {
        super(Material.ROCK); setRegistryName(name); setTranslationKey(ChaosCraft.MODID + "." + name);
        setHardness(3.0F); setResistance(5.0F); setHarvestLevel("pickaxe", 2); setCreativeTab(ChaosCraft.TAB);
    }
    @Override public Item getItemDropped(net.minecraft.block.state.IBlockState state, Random rand, int fortune) { return ModItems.CHAOS_SHARD; }
    @Override public int quantityDropped(Random random) { return 1 + random.nextInt(2); }
    @Override public int quantityDroppedWithBonus(int fortune, Random random) { return Math.min(4, quantityDropped(random) + random.nextInt(Math.max(1, fortune + 1))); }
}
