package com.chaoscraft.item;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ItemGlitchPickaxe extends ItemPickaxe {
    public ItemGlitchPickaxe(String name, ToolMaterial material) {
        super(material); setRegistryName(name); setTranslationKey("chaoscraft." + name); setCreativeTab(com.chaoscraft.ChaosCraft.TAB); setMaxDamage(500);
    }
    @Override public boolean onBlockDestroyed(ItemStack stack, World world, IBlockState state, BlockPos pos, EntityLivingBase entity) {
        boolean result = super.onBlockDestroyed(stack, world, state, pos, entity);
        if (!world.isRemote && entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;
            Vec3d look = player.getLookVec();
            boolean xPlane = Math.abs(look.x) > Math.abs(look.z);
            for (int a = -1; a <= 1; a++) for (int b = -1; b <= 1; b++) {
                if (a == 0 && b == 0) continue;
                BlockPos target = xPlane ? pos.add(0, a, b) : pos.add(a, b, 0);
                if (target.equals(pos) || world.isAirBlock(target) || world.getBlockState(target).getBlockHardness(world, target) < 0) continue;
                TileEntity tile = world.getTileEntity(target);
                if (tile != null || world.getBlockState(target).getBlock() == net.minecraft.init.Blocks.BEDROCK) continue;
                // Extra blocks are deliberately limited to ordinary blocks to avoid container loss.
                boolean broken = world.destroyBlock(target, true);
                if (broken && world.rand.nextInt(5) == 0 && world.isAirBlock(target)) {
                    net.minecraft.block.Block[] luckyBlocks = new net.minecraft.block.Block[] {
                            net.minecraft.init.Blocks.SPONGE, net.minecraft.init.Blocks.GLASS,
                            net.minecraft.init.Blocks.DIAMOND_BLOCK, net.minecraft.init.Blocks.GOLD_BLOCK,
                            net.minecraft.init.Blocks.GRAVEL
                    };
                    net.minecraft.block.Block replacement = luckyBlocks[world.rand.nextInt(luckyBlocks.length)];
                    world.setBlockState(target, replacement.getDefaultState(), 3);
                }
            }
            stack.damageItem(1, player);
        }
        return result;
    }
}
