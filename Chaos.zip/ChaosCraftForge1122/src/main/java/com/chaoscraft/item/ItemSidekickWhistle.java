package com.chaoscraft.item;

import com.chaoscraft.entity.EntityBuildBuddy;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.World;
import java.util.List;

public class ItemSidekickWhistle extends ItemBase {
    public ItemSidekickWhistle(String name) { super(name); setMaxStackSize(1); }
    @Override public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!world.isRemote) {
            List<EntityBuildBuddy> buddies = world.getEntitiesWithinAABB(EntityBuildBuddy.class,
                    new AxisAlignedBB(player.posX - 48, player.posY - 24, player.posZ - 48, player.posX + 48, player.posY + 24, player.posZ + 48));
            EntityBuildBuddy owned = null;
            for (EntityBuildBuddy buddy : buddies) if (buddy.isOwner(player)) { owned = buddy; break; }
            if (owned == null) {
                EntityBuildBuddy buddy = new EntityBuildBuddy(world);
                buddy.setPosition(player.posX + 1.0D, player.posY, player.posZ + 1.0D);
                buddy.setTamed(true);
                buddy.setOwnerId(player.getUniqueID());
                world.spawnEntity(buddy);
            } else {
                owned.setPosition(player.posX + 1.0D, player.posY, player.posZ + 1.0D);
            }
            player.getCooldownTracker().setCooldown(this, 40);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }
}
