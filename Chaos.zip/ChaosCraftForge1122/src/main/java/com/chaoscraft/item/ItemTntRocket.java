package com.chaoscraft.item;
public class ItemTntRocket extends ItemBase {
    public ItemTntRocket(String name) { super(name); }
}
