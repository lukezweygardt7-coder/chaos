package com.chaoscraft.item;

import com.chaoscraft.config.ChaosConfig;
import com.chaoscraft.entity.EntityChaosRocket;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class ItemChaosLauncher extends ItemBase {
    public ItemChaosLauncher(String name) { super(name); setMaxStackSize(1); setMaxDamage(180); }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack held = player.getHeldItem(hand);
        if (!player.capabilities.isCreativeMode && !player.inventory.hasItemStack(new ItemStack(ModItems.TNT_ROCKET))) {
            return new ActionResult<>(EnumActionResult.FAIL, held);
        }
        if (!world.isRemote) {
            EntityChaosRocket rocket = new EntityChaosRocket(world, player, ChaosConfig.LAUNCHER_POWER, ChaosConfig.ALLOW_BLOCK_DAMAGE);
            rocket.shoot(player.getLookVec().x, player.getLookVec().y, player.getLookVec().z, 1.8F, 0.4F);
            world.spawnEntity(rocket);
            if (!player.capabilities.isCreativeMode) consumeOneRocket(player);
            held.damageItem(1, player);
            player.getCooldownTracker().setCooldown(this, 8);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, held);
    }

    private void consumeOneRocket(EntityPlayer player) {
        for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
            ItemStack s = player.inventory.getStackInSlot(i);
            if (!s.isEmpty() && s.getItem() == ModItems.TNT_ROCKET) {
                s.shrink(1);
                return;
            }
        }
    }
}
