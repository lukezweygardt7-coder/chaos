package com.chaoscraft.item;

import com.chaoscraft.ChaosCraft;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;

@Mod.EventBusSubscriber(modid = ChaosCraft.MODID)
public final class ModItems {
    private ModItems() { }

    public static final Item YEET_STICK = new ItemYeetStick("yeet_stick");
    public static final Item CHAOS_LAUNCHER = new ItemChaosLauncher("chaos_launcher");
    public static final Item TNT_ROCKET = new ItemTntRocket("tnt_rocket");
    public static final Item TNT_EGG = new ItemTntEgg("tnt_egg");
    public static final Item RANDOMIZER_SWORD = new ItemRandomizerSword("randomizer_sword", Item.ToolMaterial.IRON);
    public static final Item GLITCH_PICKAXE = new ItemGlitchPickaxe("glitch_pickaxe", Item.ToolMaterial.IRON);
    public static final Item CHAOS_TONIC = new ItemChaosTonic("chaos_tonic");
    public static final Item SIDEKICK_WHISTLE = new ItemSidekickWhistle("sidekick_whistle");
    public static final Item CHAOS_SHARD = new ItemBase("chaos_shard");

    private static final ItemArmor.ArmorMaterial BOUNCE_MATERIAL = EnumHelper.addArmorMaterial(
            "CHAOS_BOUNCE", ChaosCraft.MODID + ":bounce", 8, new int[]{1, 2, 2, 1}, 12,
            net.minecraft.init.SoundEvents.ITEM_ARMOR_EQUIP_LEATHER, 0.0F);
    public static final Item BOUNCE_BOOTS = new ItemBounceBoots("bounce_boots", BOUNCE_MATERIAL, EntityEquipmentSlot.FEET);

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(YEET_STICK, CHAOS_LAUNCHER, TNT_ROCKET, TNT_EGG,
                RANDOMIZER_SWORD, GLITCH_PICKAXE, CHAOS_TONIC, SIDEKICK_WHISTLE,
                CHAOS_SHARD, BOUNCE_BOOTS);
    }
}
