package com.chaoscraft.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ItemYeetStick extends ItemBase {
    public ItemYeetStick(String name) { super(name); setMaxStackSize(1); }

    @Override
    public boolean itemInteractionForEntity(ItemStack stack, EntityPlayer player, EntityLivingBase target, EnumHand hand) {
        if (player.world.isRemote) return true;
        Vec3d look = player.getLookVec();
        target.addVelocity(look.x * 1.5D, 2.6D, look.z * 1.5D);
        target.velocityChanged = true;
        player.getCooldownTracker().setCooldown(this, 12);
        return true;
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (player.isSneaking() && !world.isRemote) {
            Vec3d look = player.getLookVec();
            player.addVelocity(look.x * 1.8D, 1.7D, look.z * 1.8D);
            player.velocityChanged = true;
            player.getCooldownTracker().setCooldown(this, 35);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }
}
