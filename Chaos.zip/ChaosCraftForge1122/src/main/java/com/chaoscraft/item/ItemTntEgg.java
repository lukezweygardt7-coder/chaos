package com.chaoscraft.item;

import com.chaoscraft.entity.EntityChaosRocket;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class ItemTntEgg extends ItemBase {
    public ItemTntEgg(String name) { super(name); setMaxStackSize(16); }
    @Override public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!world.isRemote) {
            EntityChaosRocket egg = new EntityChaosRocket(world, player, 1.15F, false);
            egg.shoot(player.getLookVec().x, player.getLookVec().y, player.getLookVec().z, 1.25F, 1.0F);
            world.spawnEntity(egg);
            if (!player.capabilities.isCreativeMode) stack.shrink(1);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }
}
