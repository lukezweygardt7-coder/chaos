package com.chaoscraft.item;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public class ItemBounceBoots extends ItemArmor {
    public ItemBounceBoots(String name, ArmorMaterial material, EntityEquipmentSlot slot) {
        super(material, 0, slot); setRegistryName(name); setTranslationKey("chaoscraft." + name); setCreativeTab(com.chaoscraft.ChaosCraft.TAB);
    }
    @Override public void onArmorTick(net.minecraft.world.World world, EntityPlayer player, ItemStack stack) {
        if (world.isRemote || !player.onGround || player.isSneaking()) return;
        long next = player.getEntityData().getLong("chaoscraft_next_bounce");
        if (world.getTotalWorldTime() >= next && player.moveForward != 0.0F) {
            player.motionY = 0.72D;
            player.fallDistance = 0.0F;
            player.getEntityData().setLong("chaoscraft_next_bounce", world.getTotalWorldTime() + 14L);
        }
    }
}
