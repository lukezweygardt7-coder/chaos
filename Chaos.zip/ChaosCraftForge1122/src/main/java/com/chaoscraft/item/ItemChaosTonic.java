package com.chaoscraft.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class ItemChaosTonic extends ItemBase {
    public ItemChaosTonic(String name) { super(name); setMaxStackSize(16); }
    @Override public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!world.isRemote) {
            int choice = world.rand.nextInt(6);
            switch (choice) {
                case 0: player.addPotionEffect(new PotionEffect(MobEffects.SPEED, 500, 2)); break;
                case 1: player.addPotionEffect(new PotionEffect(MobEffects.JUMP_BOOST, 500, 3)); break;
                case 2: player.addPotionEffect(new PotionEffect(MobEffects.HASTE, 500, 2)); break;
                case 3: player.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 300, 1)); break;
                case 4: player.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 160, 0)); break;
                default: player.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 400, 0)); break;
            }
            if (!player.capabilities.isCreativeMode) stack.shrink(1);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }
}
