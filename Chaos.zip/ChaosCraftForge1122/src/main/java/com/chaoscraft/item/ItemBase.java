package com.chaoscraft.item;

import com.chaoscraft.ChaosCraft;
import net.minecraft.item.Item;

public class ItemBase extends Item {
    public ItemBase(String name) {
        setRegistryName(name);
        setTranslationKey(ChaosCraft.MODID + "." + name);
        setCreativeTab(ChaosCraft.TAB);
    }
}
