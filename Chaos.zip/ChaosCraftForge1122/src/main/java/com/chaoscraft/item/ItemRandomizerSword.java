package com.chaoscraft.item;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import java.util.Arrays;
import java.util.List;

public class ItemRandomizerSword extends ItemSword {
    private final List<Block> replacements = Arrays.asList(net.minecraft.init.Blocks.SPONGE,
            net.minecraft.init.Blocks.GRAVEL, net.minecraft.init.Blocks.DIRT,
            net.minecraft.init.Blocks.GLASS, net.minecraft.init.Blocks.GLOWSTONE, net.minecraft.init.Blocks.DIAMOND_BLOCK, net.minecraft.init.Blocks.GOLD_BLOCK);
    public ItemRandomizerSword(String name, ToolMaterial material) {
        super(material); setRegistryName(name); setTranslationKey("chaoscraft." + name); setCreativeTab(com.chaoscraft.ChaosCraft.TAB); setMaxDamage(420);
    }
    @Override public boolean onBlockDestroyed(ItemStack stack, World world, IBlockState state, BlockPos pos, EntityLivingBase entity) {
        boolean result = super.onBlockDestroyed(stack, world, state, pos, entity);
        if (!world.isRemote && world.isAirBlock(pos) && world.rand.nextInt(3) == 0) {
            Block chosen = replacements.get(world.rand.nextInt(replacements.size()));
            world.setBlockState(pos, chosen.getDefaultState(), 3);
        }
        return result;
    }
}
