package com.chaoscraft.client;

import com.chaoscraft.CommonProxy;
import com.chaoscraft.entity.EntityBuildBuddy;
import com.chaoscraft.entity.EntityChaosGremlin;
import com.chaoscraft.entity.EntityMegaChicken;
import com.chaoscraft.entity.EntityTNTChicken;
import com.chaoscraft.entity.EntityChaosRocket;
import net.minecraft.client.renderer.entity.RenderSnowball;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.item.Item;
import com.chaoscraft.item.ModItems;
import com.chaoscraft.block.ModBlocks;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.common.MinecraftForge;

public class ClientProxy extends CommonProxy {
    @Override public void preInit() {
        RenderingRegistry.registerEntityRenderingHandler(EntityChaosGremlin.class, RenderGremlin::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityBuildBuddy.class, RenderBuildBuddy::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityMegaChicken.class,
                manager -> new RenderChaosChicken(manager, "chaoscraft:textures/entity/mega_chicken.png", 1.55F));
        RenderingRegistry.registerEntityRenderingHandler(EntityTNTChicken.class,
                manager -> new RenderChaosChicken(manager, "chaoscraft:textures/entity/tnt_chicken.png", 1.0F));
        RenderingRegistry.registerEntityRenderingHandler(EntityChaosRocket.class,
                manager -> new RenderSnowball<>(manager, com.chaoscraft.item.ModItems.TNT_EGG, net.minecraft.client.Minecraft.getMinecraft().getRenderItem()));
        MinecraftForge.EVENT_BUS.register(new ScreenShake());
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onModelRegistry(ModelRegistryEvent event) {
        registerItemModels();
    }

    private void registerItemModels() {
        register(ModItems.YEET_STICK); register(ModItems.CHAOS_LAUNCHER); register(ModItems.TNT_ROCKET);
        register(ModItems.TNT_EGG); register(ModItems.RANDOMIZER_SWORD); register(ModItems.GLITCH_PICKAXE);
        register(ModItems.CHAOS_TONIC); register(ModItems.SIDEKICK_WHISTLE); register(ModItems.CHAOS_SHARD);
        register(ModItems.BOUNCE_BOOTS);
        register(ModBlocks.CHAOS_ORE_ITEM); register(ModBlocks.BOUNCE_SLIME_ITEM);
    }
    private void register(Item item) {
        ModelLoader.setCustomModelResourceLocation(item, 0,
                new ModelResourceLocation(item.getRegistryName(), "inventory"));
    }
}
