package com.chaoscraft.client;

import com.chaoscraft.ChaosCraft;
import com.chaoscraft.config.ChaosConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraftforge.common.config.ConfigElement;
import net.minecraftforge.fml.client.IModGuiFactory;
import net.minecraftforge.fml.client.config.GuiConfig;
import net.minecraftforge.fml.client.config.IConfigElement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/** Real Forge Mods -> Config screen backed by config/chaoscraft.cfg. */
public class ChaosGuiFactory implements IModGuiFactory {
    @Override public void initialize(Minecraft minecraftInstance) { }
    @Override public boolean hasConfigGui() { return true; }
    @Override public GuiScreen createConfigGui(GuiScreen parentScreen) { return new ChaosConfigScreen(parentScreen); }
    @Override public Set<RuntimeOptionCategoryElement> runtimeGuiCategories() { return Collections.emptySet(); }

    public static class ChaosConfigScreen extends GuiConfig {
        public ChaosConfigScreen(GuiScreen parent) {
            super(parent, getElements(), ChaosCraft.MODID, false, false,
                    I18n.format("gui.chaoscraft.config.title"));
        }
        private static List<IConfigElement> getElements() {
            List<IConfigElement> elements = new ArrayList<>();
            if (ChaosConfig.getConfig() != null) {
                elements.add(new ConfigElement(ChaosConfig.getConfig().getCategory(net.minecraftforge.common.config.Configuration.CATEGORY_GENERAL)));
            }
            return elements;
        }
    }
}
