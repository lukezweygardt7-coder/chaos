package com.chaoscraft.client;

import com.chaoscraft.config.ChaosConfig;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.util.Random;

public class ScreenShake {
    private static volatile int remaining;
    private static final Random RANDOM = new Random();
    public static void start(int ticks) { if (ChaosConfig.ENABLE_SCREEN_SHAKE) remaining = Math.max(remaining, Math.min(100, ticks)); }

    @SubscribeEvent public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && remaining > 0) remaining--;
    }
    @SubscribeEvent public void onCamera(EntityViewRenderEvent.CameraSetup event) {
        if (ChaosConfig.ENABLE_SCREEN_SHAKE && remaining > 0) {
            float amount = Math.min(0.7F, remaining / 18.0F) * 0.35F;
            event.setRoll(event.getRoll() + (RANDOM.nextFloat() - 0.5F) * amount * 2.0F);
            event.setPitch(event.getPitch() + (RANDOM.nextFloat() - 0.5F) * amount * 1.5F);
        }
    }
}
