package com.chaoscraft.client;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderChicken;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.util.ResourceLocation;

public class RenderChaosChicken extends RenderChicken {
    private final ResourceLocation texture;
    private final float scale;
    public RenderChaosChicken(RenderManager manager, String texturePath, float scale) {
        super(manager); this.texture = new ResourceLocation(texturePath); this.scale = scale;
    }
    @Override protected ResourceLocation getEntityTexture(EntityChicken entity) { return texture; }
    @Override protected void preRenderCallback(EntityChicken entity, float partialTickTime) { GlStateManager.scale(scale, scale, scale); }
}
