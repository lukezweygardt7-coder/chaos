package com.chaoscraft.client;

import com.chaoscraft.entity.EntityBuildBuddy;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderBuildBuddy extends RenderLiving<EntityBuildBuddy> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("chaoscraft:textures/entity/build_buddy.png");
    public RenderBuildBuddy(RenderManager manager) { super(manager, new ModelBiped(), 0.2F); }
    @Override protected ResourceLocation getEntityTexture(EntityBuildBuddy entity) { return TEXTURE; }
    @Override protected void preRenderCallback(EntityBuildBuddy entity, float partialTickTime) { net.minecraft.client.renderer.GlStateManager.scale(0.58F, 0.58F, 0.58F); }
}
