package com.chaoscraft.client;

import com.chaoscraft.entity.EntityChaosGremlin;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderGremlin extends RenderLiving<EntityChaosGremlin> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("chaoscraft:textures/entity/chaos_gremlin.png");
    public RenderGremlin(RenderManager manager) { super(manager, new ModelBiped(), 0.3F); }
    @Override protected ResourceLocation getEntityTexture(EntityChaosGremlin entity) { return TEXTURE; }
    @Override protected void preRenderCallback(EntityChaosGremlin entity, float partialTickTime) { net.minecraft.client.renderer.GlStateManager.scale(0.75F, 0.75F, 0.75F); }
}
