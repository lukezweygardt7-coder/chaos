package com.chaoscraft.config;

import com.chaoscraft.ChaosCraft;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.client.event.ConfigChangedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.io.File;

public class ChaosConfig {
    private static Configuration config;
    public static boolean ENABLE_RANDOM_EVENTS = true;
    public static boolean ENABLE_PARTICLES = true;
    public static boolean ENABLE_EVENT_SOUNDS = true;
    public static boolean ENABLE_SCREEN_SHAKE = true;
    public static boolean ALLOW_BLOCK_DAMAGE = false;
    public static int EVENT_MIN_TICKS = 3600;
    public static int EVENT_MAX_TICKS = 6000;
    public static int MAX_CHAOS_MOBS = 12;
    public static int CHAOS_LEVEL = 3;
    public static float LAUNCHER_POWER = 2.5F;

    public static void load(File file) {
        config = new Configuration(file);
        config.load();
        sync();
    }

    public static void sync() {
        if (config == null) return;
        String c = Configuration.CATEGORY_GENERAL;
        ENABLE_RANDOM_EVENTS = config.getBoolean("enableRandomEvents", c, true, "Enable automatic random world events.");
        ENABLE_PARTICLES = config.getBoolean("enableParticles", c, true, "Enable event particle effects.");
        ENABLE_EVENT_SOUNDS = config.getBoolean("enableEventSounds", c, true, "Enable event sounds.");
        ENABLE_SCREEN_SHAKE = config.getBoolean("enableScreenShake", c, true, "Enable short client-side screen shake.");
        ALLOW_BLOCK_DAMAGE = config.getBoolean("allowBlockDamage", c, false, "Allow launcher and event explosions to damage terrain. Disabled by default.");
        EVENT_MIN_TICKS = config.getInt("eventMinimumInterval", c, 3600, 1200, 24000, "Minimum random event interval in ticks (20 ticks = 1 second).");
        EVENT_MAX_TICKS = config.getInt("eventMaximumInterval", c, 6000, 1200, 48000, "Maximum random event interval in ticks.");
        MAX_CHAOS_MOBS = config.getInt("maximumNearbyChaosMobs", c, 12, 1, 40, "Maximum ChaosCraft mobs spawned by one event.");
        CHAOS_LEVEL = config.getInt("chaosLevel", c, 3, 1, 5, "Overall chaos intensity, from 1 to 5.");
        LAUNCHER_POWER = config.getFloat("launcherExplosionStrength", c, 2.5F, 0.5F, 6.0F, "Chaos Launcher blast strength.");
        if (EVENT_MAX_TICKS < EVENT_MIN_TICKS) EVENT_MAX_TICKS = EVENT_MIN_TICKS;
        if (config.hasChanged()) config.save();
    }

    @SubscribeEvent
    public void onConfigChanged(ConfigChangedEvent.OnConfigChangedEvent event) {
        if (event.getModID().equals(ChaosCraft.MODID)) sync();
    }

    public static Configuration getConfig() { return config; }

    public static void reload() {
        if (config != null) { config.load(); sync(); }
    }

    public static void save() {
        if (config == null) return;
        String c = Configuration.CATEGORY_GENERAL;
        config.get(c, "enableRandomEvents", true).set(ENABLE_RANDOM_EVENTS);
        config.get(c, "enableParticles", true).set(ENABLE_PARTICLES);
        config.get(c, "enableEventSounds", true).set(ENABLE_EVENT_SOUNDS);
        config.get(c, "enableScreenShake", true).set(ENABLE_SCREEN_SHAKE);
        config.get(c, "allowBlockDamage", false).set(ALLOW_BLOCK_DAMAGE);
        config.get(c, "eventMinimumInterval", 3600).set(EVENT_MIN_TICKS);
        config.get(c, "eventMaximumInterval", 6000).set(EVENT_MAX_TICKS);
        config.get(c, "maximumNearbyChaosMobs", 12).set(MAX_CHAOS_MOBS);
        config.get(c, "chaosLevel", 3).set(CHAOS_LEVEL);
        config.get(c, "launcherExplosionStrength", 2.5F).set(LAUNCHER_POWER);
        config.save();
    }
}
