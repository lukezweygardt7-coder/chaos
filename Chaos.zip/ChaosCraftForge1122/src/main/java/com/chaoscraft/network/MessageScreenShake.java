package com.chaoscraft.network;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Common-side packet. Reflection keeps client-only classes out of dedicated-server linkage. */
public class MessageScreenShake implements IMessage {
    private int ticks;
    public MessageScreenShake() { }
    public MessageScreenShake(int ticks) { this.ticks = ticks; }
    @Override public void fromBytes(ByteBuf buf) { ticks = buf.readInt(); }
    @Override public void toBytes(ByteBuf buf) { buf.writeInt(ticks); }

    public static class Handler implements IMessageHandler<MessageScreenShake, IMessage> {
        @Override public IMessage onMessage(final MessageScreenShake message, MessageContext context) {
            if (context.side.isClient()) {
                try {
                    Class<?> shake = Class.forName("com.chaoscraft.client.ScreenShake");
                    shake.getMethod("start", int.class).invoke(null, message.ticks);
                } catch (Exception ignored) { }
            }
            return null;
        }
    }
}
