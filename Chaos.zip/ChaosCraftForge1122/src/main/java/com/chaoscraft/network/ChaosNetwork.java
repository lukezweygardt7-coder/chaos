package com.chaoscraft.network;

import com.chaoscraft.ChaosCraft;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public final class ChaosNetwork {
    public static final SimpleNetworkWrapper CHANNEL = NetworkRegistry.INSTANCE.newSimpleChannel(ChaosCraft.MODID);
    private static int id = 0;
    private ChaosNetwork() { }
    public static void init() {
        CHANNEL.registerMessage(MessageScreenShake.Handler.class, MessageScreenShake.class, id++, Side.CLIENT);
    }
}
