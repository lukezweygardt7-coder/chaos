package com.chaoscraft;

import com.chaoscraft.block.ModBlocks;
import com.chaoscraft.client.ClientProxy;
import com.chaoscraft.command.CommandChaos;
import com.chaoscraft.config.ChaosConfig;
import com.chaoscraft.entity.ModEntities;
import com.chaoscraft.event.ChaosEngine;
import com.chaoscraft.item.ModItems;
import com.chaoscraft.network.ChaosNetwork;
import com.chaoscraft.world.ChaosOreGenerator;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = ChaosCraft.MODID, name = ChaosCraft.NAME, version = ChaosCraft.VERSION,
        acceptedMinecraftVersions = "[1.12.2]", dependencies = "required-after:forge@[14.23.5.2864,)",
        guiFactory = "com.chaoscraft.client.ChaosGuiFactory")
public class ChaosCraft {
    public static final String MODID = "chaoscraft";
    public static final String NAME = "ChaosCraft: Mayhem Mode";
    public static final String VERSION = "1.0.0";

    public static final CreativeTabs TAB = new CreativeTabs("chaoscraft") {
        @Override public ItemStack createIcon() { return new ItemStack(ModItems.YEET_STICK); }
    };

    @Mod.Instance(MODID)
    public static ChaosCraft INSTANCE;

    @SidedProxy(clientSide = "com.chaoscraft.client.ClientProxy", serverSide = "com.chaoscraft.CommonProxy")
    public static com.chaoscraft.CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ChaosConfig.load(event.getSuggestedConfigurationFile());
        ChaosNetwork.init();
        ModEntities.init();
        proxy.preInit();
        MinecraftForge.EVENT_BUS.register(new ChaosEngine());
        MinecraftForge.EVENT_BUS.register(new ChaosConfig());
        GameRegistry.registerWorldGenerator(new ChaosOreGenerator(), 4);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init();
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandChaos());
    }
}
