package com.chaoscraft.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityMegaChicken extends EntityChicken {
    public EntityMegaChicken(World world) { super(world); setSize(1.45F, 2.15F); }
    @Override protected void initEntityAI() {
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIAttackMelee(this, 0.95D, false));
        tasks.addTask(2, new EntityAIWander(this, 0.85D));
        tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 10.0F));
        targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
        targetTasks.addTask(2, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class, true));
    }
    @Override protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(65.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.28D);
        getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(8.0D);
    }
    @Override public void onLivingUpdate() {
        super.onLivingUpdate();
        if (!world.isRemote && ticksExisted > 2400) { setDead(); return; }
        if (!world.isRemote && getAttackTarget() != null && onGround && ticksExisted % 80 == 0) {
            motionY = 0.8D;
            world.newExplosion(this, posX, posY, posZ, 1.0F, false, false);
        }
    }
    @Override protected net.minecraft.util.SoundEvent getAmbientSound() { return net.minecraft.init.SoundEvents.ENTITY_CHICKEN_AMBIENT; }
    @Override protected net.minecraft.util.SoundEvent getHurtSound(DamageSource source) { return net.minecraft.init.SoundEvents.ENTITY_CHICKEN_HURT; }
    @Override protected net.minecraft.util.SoundEvent getDeathSound() { return net.minecraft.init.SoundEvents.ENTITY_CHICKEN_DEATH; }
}
