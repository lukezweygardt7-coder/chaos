package com.chaoscraft.entity;

import com.chaoscraft.ChaosCraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;

@Mod.EventBusSubscriber(modid = ChaosCraft.MODID)
public final class ModEntities {
    private ModEntities() { }
    private static int nextId = 1;

    public static void init() { }

    @SubscribeEvent
    public static void registerEntities(RegistryEvent.Register<EntityEntry> event) {
        event.getRegistry().registerAll(
                entry("chaos_gremlin", EntityChaosGremlin.class, 64, 3, true),
                entry("mega_chicken", EntityMegaChicken.class, 80, 3, true),
                entry("tnt_chicken", EntityTNTChicken.class, 64, 3, true),
                entry("build_buddy", EntityBuildBuddy.class, 64, 3, true),
                entry("chaos_rocket", EntityChaosRocket.class, 64, 10, true)
        );
    }

    private static EntityEntry entry(String name, Class<? extends net.minecraft.entity.Entity> type, int range, int interval, boolean velocity) {
        return EntityEntryBuilder.<net.minecraft.entity.Entity>create()
                .entity(type)
                .id(new ResourceLocation(ChaosCraft.MODID, name), nextId++)
                .name(name)
                .tracker(range, interval, velocity)
                .build();
    }
}
