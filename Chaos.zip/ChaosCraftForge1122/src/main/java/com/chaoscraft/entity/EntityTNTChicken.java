package com.chaoscraft.entity;

import com.chaoscraft.config.ChaosConfig;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityTNTChicken extends EntityChicken {
    public EntityTNTChicken(World world) { super(world); setSize(0.42F, 0.72F); }
    @Override public void onLivingUpdate() {
        super.onLivingUpdate();
        if (world.isRemote) return;
        if (ticksExisted > 1800) { setDead(); return; }
        if (ticksExisted % 100 != 0) return;
        EntityPlayer target = world.getClosestPlayerToEntity(this, 14.0D);
        if (target != null && (ChaosConfig.MAX_CHAOS_MOBS > 0)) {
            Vec3d dir = new Vec3d(target.posX - posX, target.posY + 0.7D - posY, target.posZ - posZ).normalize();
            EntityChaosRocket egg = new EntityChaosRocket(world, this, 1.0F, false);
            egg.shoot(dir.x, dir.y, dir.z, 0.9F, 3.0F);
            world.spawnEntity(egg);
        }
    }
}
