package com.chaoscraft.entity;

import com.chaoscraft.item.ModItems;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityChaosGremlin extends EntityMob {
    public EntityChaosGremlin(World world) {
        super(world); setSize(0.62F, 0.95F); experienceValue = 8;
    }
    @Override protected void initEntityAI() {
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIAttackMelee(this, 1.25D, false));
        tasks.addTask(2, new EntityAIWander(this, 1.0D));
        tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(4, new EntityAILookIdle(this));
        targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
        targetTasks.addTask(2, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class, true));
    }
    @Override protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(22.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.34D);
        getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(4.0D);
        getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(28.0D);
    }
    @Override public void onUpdate() {
        super.onUpdate();
        if (!world.isRemote && getAttackTarget() != null && ticksExisted % 100 == 0 && rand.nextInt(3) == 0) {
            EntityLivingBase target = getAttackTarget();
            double angle = rand.nextDouble() * Math.PI * 2.0D;
            setPosition(target.posX + Math.cos(angle) * (2.5D + rand.nextDouble() * 2.0D), target.posY,
                    target.posZ + Math.sin(angle) * (2.5D + rand.nextDouble() * 2.0D));
            world.playSound(null, getPosition(), net.minecraft.init.SoundEvents.ENTITY_ENDERMEN_TELEPORT,
                    net.minecraft.util.SoundCategory.HOSTILE, 0.45F, 1.6F);
        }
    }
    @Override protected Item getDropItem() { return ModItems.CHAOS_SHARD; }
    @Override protected net.minecraft.util.SoundEvent getAmbientSound() { return net.minecraft.init.SoundEvents.ENTITY_SILVERFISH_AMBIENT; }
    @Override protected net.minecraft.util.SoundEvent getHurtSound(DamageSource source) { return net.minecraft.init.SoundEvents.ENTITY_ENDERMEN_HURT; }
    @Override protected net.minecraft.util.SoundEvent getDeathSound() { return net.minecraft.init.SoundEvents.ENTITY_ENDERMEN_DEATH; }
}
