package com.chaoscraft.entity;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIFollowOwner;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAISit;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class EntityBuildBuddy extends EntityTameable {
    public EntityBuildBuddy(World world) { super(world); setSize(0.58F, 0.95F); }
    @Override protected void initEntityAI() {
        tasks.addTask(0, new net.minecraft.entity.ai.EntityAISwimming(this));
        tasks.addTask(1, new EntityAISit(this));
        tasks.addTask(2, new EntityAIFollowOwner(this, 1.15D, 5.0F, 2.0F));
        tasks.addTask(3, new EntityAIWander(this, 0.8D));
        tasks.addTask(4, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(5, new EntityAILookIdle(this));
        targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
    }
    @Override protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(30.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.30D);
    }
    @Override public EntityAgeable createChild(EntityAgeable ageable) { return new EntityBuildBuddy(world); }
    @Override public void onLivingUpdate() {
        super.onLivingUpdate();
        if (world.isRemote || !isTamed()) return;
        if (ticksExisted % 12 == 0) {
            for (EntityMob mob : world.getEntitiesWithinAABB(EntityMob.class, getEntityBoundingBox().grow(3.0D))) {
                if (isOwner(mob)) continue;
                mob.addVelocity(0.0D, 0.85D, 0.0D);
                mob.velocityChanged = true;
            }
        }
        if (ticksExisted % 420 == 0 && getOwner() != null && getDistance(getOwner()) < 9.0F) buildTinyDecor();
    }
    private void buildTinyDecor() {
        BlockPos base = new BlockPos(posX + (rand.nextInt(7) - 3), posY - 1, posZ + (rand.nextInt(7) - 3));
        if (!world.getBlockState(base).getMaterial().isSolid()) return;
        IBlockState plank = Blocks.PLANKS.getDefaultState();
        // Only build into a clear 3x3 area; never overwrite an existing structure.
        if (!world.isAirBlock(base.up(2)) || !world.isAirBlock(base.up().east().up())) return;
        for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++) {
            if (!world.isAirBlock(base.up().add(x, 0, z))) return;
        }
        for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++)
            world.setBlockState(base.up().add(x, 0, z), plank, 3);
        world.setBlockState(base.up(2), plank, 3);
        world.setBlockState(base.up().east().up(), Blocks.YELLOW_FLOWER.getDefaultState(), 3);
    }
    @Override public boolean attackEntityAsMob(Entity entity) {
        boolean hit = super.attackEntityAsMob(entity);
        if (hit) { entity.addVelocity(0.0D, 0.8D, 0.0D); entity.velocityChanged = true; }
        return hit;
    }
    @Override protected net.minecraft.util.SoundEvent getAmbientSound() { return net.minecraft.init.SoundEvents.ENTITY_VILLAGER_AMBIENT; }
    @Override protected net.minecraft.util.SoundEvent getHurtSound(DamageSource source) { return net.minecraft.init.SoundEvents.ENTITY_VILLAGER_HURT; }
    @Override protected net.minecraft.util.SoundEvent getDeathSound() { return net.minecraft.init.SoundEvents.ENTITY_VILLAGER_DEATH; }
}
