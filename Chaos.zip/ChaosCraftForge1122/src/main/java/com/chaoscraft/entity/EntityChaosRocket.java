package com.chaoscraft.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class EntityChaosRocket extends EntityThrowable {
    private float power = 2.0F;
    private boolean terrainDamage;

    public EntityChaosRocket(World world) { super(world); }
    public EntityChaosRocket(World world, EntityLivingBase thrower, float power, boolean terrainDamage) {
        super(world, thrower);
        this.power = power;
        this.terrainDamage = terrainDamage;
    }

    @Override protected void onImpact(RayTraceResult result) {
        if (!world.isRemote) {
            world.newExplosion(this, posX, posY, posZ, power, false, terrainDamage);
            for (int i = 0; i < 18; i++) {
                world.spawnParticle(net.minecraft.util.EnumParticleTypes.FIREWORKS_SPARK,
                        posX, posY, posZ, (rand.nextDouble() - 0.5D) * 0.35D,
                        rand.nextDouble() * 0.35D, (rand.nextDouble() - 0.5D) * 0.35D);
            }
            setDead();
        }
    }
}
