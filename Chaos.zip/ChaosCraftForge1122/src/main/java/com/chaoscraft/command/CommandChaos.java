package com.chaoscraft.command;

import com.chaoscraft.config.ChaosConfig;
import com.chaoscraft.event.ChaosEngine;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import java.util.ArrayList;
import java.util.List;

public class CommandChaos extends CommandBase {
    @Override public String getName() { return "chaos"; }
    @Override public String getUsage(ICommandSender sender) { return "/chaos <event <name>|level <1-5>|start|stop|reload>"; }
    @Override public int getRequiredPermissionLevel() { return 2; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) { help(sender); return; }
        String sub = args[0].toLowerCase();
        if ("start".equals(sub)) {
            ChaosConfig.ENABLE_RANDOM_EVENTS = true; ChaosConfig.save();
            sender.sendMessage(new TextComponentString("§aChaos events enabled.")); return;
        }
        if ("stop".equals(sub)) {
            ChaosConfig.ENABLE_RANDOM_EVENTS = false; ChaosConfig.save();
            sender.sendMessage(new TextComponentString("§cAutomatic chaos events disabled.")); return;
        }
        if ("reload".equals(sub)) {
            ChaosConfig.reload(); sender.sendMessage(new TextComponentString("§aChaosCraft settings reloaded.")); return;
        }
        if ("level".equals(sub) && args.length >= 2) {
            try {
                int level = Integer.parseInt(args[1]);
                ChaosConfig.CHAOS_LEVEL = Math.max(1, Math.min(5, level));
                ChaosConfig.save();
                sender.sendMessage(new TextComponentString("§eChaos level set to " + ChaosConfig.CHAOS_LEVEL + "."));
            } catch (NumberFormatException e) { throw new CommandException("Chaos level must be a number from 1 to 5."); }
            return;
        }
        if ("event".equals(sub) && args.length >= 2 && "list".equalsIgnoreCase(args[1])) { listEvents(sender); return; }
        if ("event".equals(sub) && args.length >= 2) {
            String wanted = args[1].toUpperCase();
            if ("STOP".equals(wanted)) { sender.sendMessage(new TextComponentString("§7The current event will finish naturally; use /chaos stop to disable automatic events.")); return; }
            for (ChaosEngine.ChaosEvent type : ChaosEngine.ChaosEvent.values()) {
                if (type.name().equals(wanted)) {
                    World world = sender.getEntityWorld();
                    ChaosEngine.trigger(world, type);
                    sender.sendMessage(new TextComponentString("§aTriggered event: " + type.name().toLowerCase() + "."));
                    return;
                }
            }
            throw new CommandException("Unknown event. Try /chaos event list.");
        }
        help(sender);
    }

    private void help(ICommandSender sender) {
        sender.sendMessage(new TextComponentString("§6ChaosCraft commands:"));
        sender.sendMessage(new TextComponentString("§e/chaos event list §7- list available events"));
        sender.sendMessage(new TextComponentString("§e/chaos event <name> §7- trigger an event"));
        sender.sendMessage(new TextComponentString("§e/chaos level <1-5> §7- set event intensity"));
        sender.sendMessage(new TextComponentString("§e/chaos start|stop|reload §7- control automatic events/settings"));
    }
    private void listEvents(ICommandSender sender) {
        StringBuilder b = new StringBuilder("§6Events: §e");
        for (ChaosEngine.ChaosEvent type : ChaosEngine.ChaosEvent.values()) b.append(type.name().toLowerCase()).append("  ");
        sender.sendMessage(new TextComponentString(b.toString()));
    }

    @Override public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, net.minecraft.util.math.BlockPos targetPos) {
        List<String> result = new ArrayList<>();
        if (args.length == 1) { result.add("event"); result.add("level"); result.add("start"); result.add("stop"); result.add("reload"); }
        else if (args.length == 2 && "event".equalsIgnoreCase(args[0])) {
            result.add("list"); for (ChaosEngine.ChaosEvent type : ChaosEngine.ChaosEvent.values()) result.add(type.name().toLowerCase());
        } else if (args.length == 2 && "level".equalsIgnoreCase(args[0])) { result.add("1"); result.add("2"); result.add("3"); result.add("4"); result.add("5"); }
        return getListOfStringsMatchingLastWord(args, result);
    }
}
