package com.chaoscraft.world;

import com.chaoscraft.block.ModBlocks;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraftforge.fml.common.IWorldGenerator;
import java.util.Random;

public class ChaosOreGenerator implements IWorldGenerator {
    private final WorldGenMinable generator = new WorldGenMinable(ModBlocks.CHAOS_ORE.getDefaultState(), 4);
    @Override public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.provider.getDimension() != 0) return;
        for (int i = 0; i < 3; i++) {
            int x = chunkX * 16 + random.nextInt(16);
            int y = 6 + random.nextInt(42);
            int z = chunkZ * 16 + random.nextInt(16);
            generator.generate(world, random, new BlockPos(x, y, z));
        }
    }
}
