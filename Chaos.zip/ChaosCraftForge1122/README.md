# ChaosCraft: Mayhem Mode — Forge 1.12.2

**Minecraft:** Java Edition 1.12.2  
**Forge:** 14.23.5.2860  
**Java target:** Java 8  
**Project version:** 1.0.0

ChaosCraft adds random world events, chaotic utility items, a few custom creatures, original pixel textures, and a Forge configuration file.

## Included in this first source build

### Random events
- Gravity Flip (updraft launch)
- TNT Chicken Invasion
- Slime Rain
- Trampoline World
- Giant Mode (Mega Chicken encounter)
- Tiny Trouble (speed and jump effects)
- Chicken Stampede
- Meteor Party (visual meteor particle shower)
- Disco Apocalypse
- Super Speed
- Rubber World
- Gremlin Ambush

### Items and blocks
- Yeet Stick
- Bounce Boots
- Chaos Launcher and TNT Rockets
- TNT Eggs
- Randomizer Sword
- Glitch Pickaxe (3x3 area break on a safe block plane)
- Chaos Tonic
- Sidekick Whistle
- Chaos Shard
- Chaos Ore (Overworld generation)
- Bounce Slime Block

### Creatures
- Chaos Gremlin
- Mega Chicken
- TNT Chicken
- Build Buddy

## Controls and commands

All normal items use right-click. The Yeet Stick can launch a creature by right-clicking it; sneak + right-click launches the player. The Sidekick Whistle summons or recalls a Build Buddy.

Operator commands:

```text
/chaos
/chaos event list
/chaos event gravity_flip
/chaos event tnt_chickens
/chaos event gremlin_ambush
/chaos level 1
/chaos level 5
/chaos stop
/chaos start
/chaos reload
```

Event names are the lowercase enum names shown by `/chaos event list`.

## Configuration

On first launch, Forge creates:

```text
config/chaoscraft.cfg
```

Open **Mods → ChaosCraft: Mayhem Mode → Config** from the Forge Mods screen to change the settings. The config contains the automatic event toggle, particles, event sounds, screen shake, terrain damage, event timing, mob cap, chaos level, and launcher strength.

The default launcher and event effects do **not** damage terrain. Turn `allowBlockDamage` on only if you want explosions to alter blocks.

If the config screen is closed after editing, Forge saves the values and ChaosCraft reloads them through `ConfigChangedEvent`.

## GitHub ZIP build workflow

The workflow is at:

```text
.github/workflows/build.yml
```

This project ZIP contains that workflow file. For your existing repository, first replace its old Rose-specific `.github/workflows/build.yml` with the standalone `ChaosCraft-build.yml` supplied alongside this source ZIP (save it at `.github/workflows/build.yml`). Then upload `ChaosCraft-Forge1122-Source.zip` to the repository root. The workflow searches root ZIP files for the ChaosCraft marker source and extracts the correct project automatically; you do not have to extract the ZIP yourself.

For a fresh repository, add `ChaosCraft-build.yml` at `.github/workflows/build.yml`, then upload the source ZIP to the root. GitHub Actions will:

1. Find and extract the uploaded source ZIP.
2. Set up Java 8.
3. Install Gradle 7.6.4.
4. Build with ForgeGradle 5.1.77 and Forge 1.12.2-14.23.5.2860.
5. Verify the main class, metadata, recipe, texture, and Java 8 bytecode version are present in the JAR.
6. Upload `ChaosCraft-1.0.0-Forge-1.12.2.jar` as an Actions artifact.

If you upload a new source ZIP but do not see a workflow run, use the repository's **Actions → Build ChaosCraft 1.12.2 → Run workflow** button after confirming that `build.yml` is in `.github/workflows/`.

## Installation in Mojo Launcher / Quest

1. Download the JAR artifact from the successful GitHub Actions run.
2. Open the Minecraft 1.12.2 Forge 14.23.5.2860 profile in Mojo Launcher.
3. Open that profile's game directory and locate its `mods` folder.
4. Put the JAR directly in `mods`.
5. Launch that Forge profile.

Do not put the source ZIP or workflow YAML in the `mods` folder. The `chaoscraft.cfg` file belongs in the profile's `config` folder.

## Important implementation notes

- Automatic events are server-side; screen shake is a client-side packet effect.
- Explosion terrain damage is off by default.
- The randomizer sword uses a limited replacement list, not arbitrary blocks.
- The Glitch Pickaxe extra mining skips tile entities and bedrock, but it is a broad 3x3 break mechanic and should be tested on a copy of a survival world before use.
- Meteor Party is currently a visual particle shower, not destructive meteor impacts.
- Bounce Boots and some event effects use vanilla potion/velocity mechanics for compatibility with 1.12.2.
- Creature models in this first release use vanilla-compatible biped/chicken model geometry with original textures; they are not yet bespoke animated geometry rigs.

## Texture editing guide

All textures are ordinary PNG files. Edit them with Aseprite, LibreSprite, Piskel, GIMP, or another pixel editor. Keep nearest-neighbor scaling and preserve the filenames and paths.

```text
src/main/resources/assets/chaoscraft/textures/items/      10 item icons
src/main/resources/assets/chaoscraft/textures/blocks/     2 block textures
src/main/resources/assets/chaoscraft/textures/entity/     4 entity skins
src/main/resources/assets/chaoscraft/textures/particle/   6 original particle sprites
src/main/resources/assets/chaoscraft/textures/models/armor/ 2 armor-layer textures
src/main/resources/assets/chaoscraft/recipes/              10 crafting recipes
```

### Asset checklist

**Items (32x32 unless noted):**
- [x] `yeet_stick.png` — crooked wood stick with glowing pink tip.
- [x] `chaos_launcher.png` — purple/orange toy launcher.
- [x] `tnt_rocket.png` — red rocket with yellow nose and fuse.
- [x] `tnt_egg.png` — white egg with TNT stripe.
- [x] `randomizer_sword.png` — rainbow/glitch blade.
- [x] `glitch_pickaxe.png` — cyan and purple pickaxe.
- [x] `chaos_tonic.png` — potion bottle with turquoise/purple liquid.
- [x] `sidekick_whistle.png` — gold whistle with pink heart.
- [x] `chaos_shard.png` — faceted purple/cyan crystal.
- [x] `bounce_boots.png` — blue boots with pink panels and mint soles.

**Blocks (16x16):**
- [x] `chaos_ore.png` — deep violet stone with glowing cyan/purple fragments.
- [x] `bounce_slime.png` — mint and turquoise slime tile with glossy pixels.

**Entities:**
- [x] `chaos_gremlin.png` — 64x64 biped skin, green/purple gremlin colors and bright eyes.
- [x] `build_buddy.png` — 64x64 biped skin, blue body, pink accents, bright face.
- [x] `mega_chicken.png` — 64x32 chicken skin, golden body and red comb.
- [x] `tnt_chicken.png` — 64x32 chicken skin, white feathers and red/orange TNT markings.

**Particles (16x16):**
- [x] Chaos Spark, Yeet Trail, Slime Splash, Glitch Particle, Explosion Spark, Companion Heart.

## Known first-release limitations

This is a real source project, but it has not yet been built and launched in a live Forge 1.12.2 client in this environment. The GitHub Actions build is the first authoritative compile test. Any compiler failure should be fixed from the actual Actions log, then the project ZIP should be regenerated. Runtime behavior, rendering, and Quest/Android compatibility still require in-game testing.
